let confettis = [];
let t;
let walker;
let numConfettis = 50;

let backgroundHue = 0;

// i added a sound in the assets folder, if we have time we can add it

function setup() {
  let canvas = createCanvas(800, 500);
  canvas.parent("p5-canvas-container");

  colorMode(HSB); // HUE SATURATION BRIGHTNESS
  backgroundHue = random(360);

  t = new Target(200, 200);
  walker = new Eater();
}

function draw() {
  background(backgroundHue, 10, 190);


  // display the target
  t.update();
  t.display();


  // display the eater
  // walker.update();
  walker.display();



  // add confetti sometimes
  if(frameCount % 200 == 0){
    for(let i = 0; i < numConfettis; i++){
      confettis.push( new Confetti(500, 100) )
    }
  }


  // display the confetti
  for(let i = 0; i < confettis.length; i++){
    confettis[i].update();
    confettis[i].display();
    confettis[i].checkOnScreen();
  }
  
  // delete confettis that are not on screen
  // for(let i = 0; i < confettis.length; i++){
  for(let i = confettis.length-1; i >= 0 ; i--){
    if(confettis[i].onScreen == false){
      // this confetti should go
      confettis.splice(i, 1);
    }
  }


}

class Confetti{
  constructor(startX, startY){
    this.x = startX;
    this.y = startY;
    this.size = random(2, 10);
    
    this.speedX = random(-2, 2);
    this.speedY = random(-1, -3);

    this.c = color(random(360), 255, 255)
    
    this.onScreen = true;
  }
  update(){
    this.x+=this.speedX;
    this.speedX *= 0.99;
   
    this.y+=this.speedY;
    this.speedY += 0.1;
  }
  display(){    
    push();
    translate(this.x, this.y);

      fill(this.c);
      noStroke();
      circle(0, 0, this.size);
   
    pop();
  }
  checkOnScreen(){
    if(this.y > height){
      this.onScreen = false;
    }
  }

}

class Target{
  constructor(startX, startY){
    this.x = startX;
    this.y = startY;
    this.active = true;

  }
  update(){
    // optional: make the target move?
    // or make it move sporadically? 

  }
  display(){
    push();
    translate(this.x, this.y);
    fill(0)
    circle(0, 0, 10)
    pop();
  }
  checkIfClicked(){
    // get the distance between mouse and the target
    
    // using the distance, find out if the target was found

        // if it was found... change its location? 

  }

}


class Eater{
  constructor(){

  }

}

function mousePressed(){
  
}